
import bs4
import requests
import time
from bs4 import BeautifulSoup
import html5lib
import lxml
#from bs4 import BeautifulSoup

def parsePrice():
	r=requests.get('https://finance.yahoo.com/quote/AAPL?p=AAPL&.tsrc=fin-srch')
	soup = bs4.BeautifulSoup(r.text,"lxml")
	price = soup.find_all('div', {'class': 'My(6px) Pos(r) smartphone_Mt(6px)'})[0].find('span').text
	return price
#[].find('span').text
#html5lib
while True:
	print('Price: ' + str(parsePrice()))
	time.sleep(1)
#soup.find_all('div', {'class': 'D(ib) smartphone_Mb(10px) W(70%) W(100%)--mobp smartphone_Mt.(6px)'})
#My(6px) Pos(r) smartphone_Mt(6px)




'''
import urllib.request
searchStr = input("Enter Search Query \n")
r = urllib.request.urlopen("https://cve.mitre.org/cgi-bin/cvekey.cgi?")
keyword="+searchStr)"
source_code = r.read()
from bs4 import BeautifulSoup
soup = BeautifulSoup(source_code, 'html.parser')

# FIRST OF ALL SEE THAT THE ID "TableWithRules" is associated to the divtag 

table = soup.find('div', {"id" : 'TableWithRules'})
rows=table.find_all("tr")   # here you have to use find_all for finding all rows of table
for tr in rows:
    cols = tr.find_all('td') #here also you have to use find_all for finding all columns of current row
    if cols==[]: # This is a sanity check if columns are empty it will jump to next row
        continue
    p = cols[0].text.strip()
    d = cols[1].text.strip()
    print(p)
    print(d)
	'''